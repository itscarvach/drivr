interface Environment {
  apiBaseUrl: string;
  apiKey: string;
}

export const env: Environment = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL || 'https://fleetbase.eastus.cloudapp.azure.com',
  apiKey: import.meta.env.VITE_API_KEY || '',
};