import React, { createContext, useContext, useState, useCallback } from 'react';
import { AuthState, OTPResponse, AuthResponse } from '../types/auth';
import { auth } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';

interface AuthContextType extends AuthState {
  requestOTP: (phone: string) => Promise<OTPResponse>;
  verifyOTP: (otp: string, userType: string) => Promise<AuthResponse>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [state, setState] = useState<AuthState>({
    accessToken: localStorage.getItem('accessToken'),
    userUUID: localStorage.getItem('userUUID'),
    messageUUID: localStorage.getItem('messageUUID'),
    isAuthenticated: !!localStorage.getItem('accessToken'),
  });

  const requestOTP = useCallback(async (phone: string): Promise<OTPResponse> => {
    setIsLoading(true);
    try {
      const response = await auth.requestOTP(phone);
      localStorage.setItem('userUUID', response.userUUID);
      localStorage.setItem('messageUUID', response.messageUUID);
      setState(prev => ({ 
        ...prev, 
        userUUID: response.userUUID,
        messageUUID: response.messageUUID 
      }));
      return response;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to send OTP';
      toast.error(message);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const verifyOTP = useCallback(async (otp: string, userType: string): Promise<AuthResponse> => {
    if (!state.messageUUID) {
      throw new Error('Message UUID not found');
    }
    
    setIsLoading(true);
    try {
      const response = await auth.verifyOTP(otp, state.messageUUID);
      localStorage.setItem('accessToken', response.accessToken);
      setState(prev => ({ 
        ...prev, 
        accessToken: response.accessToken,
        isAuthenticated: true 
      }));
      return response;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to verify OTP';
      toast.error(message);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [state.messageUUID]);

  const logout = useCallback(() => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('userUUID');
    localStorage.removeItem('messageUUID');
    setState({ 
      accessToken: null, 
      userUUID: null, 
      messageUUID: null, 
      isAuthenticated: false 
    });
    navigate('/');
  }, [navigate]);

  return (
    <AuthContext.Provider value={{ ...state, requestOTP, verifyOTP, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};