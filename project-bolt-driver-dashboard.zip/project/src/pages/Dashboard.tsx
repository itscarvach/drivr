import React, { useEffect, useState } from 'react';
import { drivers } from '../services/api';
import { Driver } from '../types/driver';
import { toast } from 'react-hot-toast';
import { Users, CheckCircle, XCircle } from 'lucide-react';
import { format } from 'date-fns';

export default function Dashboard() {
  const [driversList, setDriversList] = useState<Driver[]>([]);

  useEffect(() => {
    fetchDrivers();
  }, []);

  const fetchDrivers = async () => {
    try {
      const response = await drivers.list();
      setDriversList(response.data);
    } catch (error) {
      toast.error('Failed to fetch drivers');
    }
  };

  const handleDocumentApproval = async (driverUUID: string, type: string, status: string) => {
    try {
      await drivers.approveDocument(driverUUID, type, status);
      toast.success(`Document ${status.toLowerCase()}`);
      fetchDrivers();
    } catch (error) {
      toast.error('Failed to update document status');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold flex items-center">
              <Users className="mr-2" /> Driver Management
            </h1>
            <span className="text-sm text-gray-500">
              Last updated: {format(new Date(), 'PPp')}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Phone
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Documents
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {driversList.map((driver) => (
                  <tr key={driver.uuid}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {driver.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {driver.phone}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        driver.status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {driver.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {driver.documents.map((doc) => (
                        <div key={doc.type} className="flex items-center space-x-2 mb-2">
                          <span className="text-sm font-medium">{doc.type}:</span>
                          <button
                            onClick={() => handleDocumentApproval(driver.uuid, doc.type, 'APPROVED')}
                            className="text-green-600 hover:text-green-800"
                          >
                            <CheckCircle size={16} />
                          </button>
                          <button
                            onClick={() => handleDocumentApproval(driver.uuid, doc.type, 'REJECTED')}
                            className="text-red-600 hover:text-red-800"
                          >
                            <XCircle size={16} />
                          </button>
                        </div>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}