import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { Phone, KeyRound } from 'lucide-react';

const phoneRegex = /^\d{10}$/;

export default function Login() {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);
  const { requestOTP, verifyOTP, isLoading } = useAuth();
  const navigate = useNavigate();

  const handleRequestOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneRegex.test(phone)) {
      toast.error('Please enter a valid 10-digit phone number');
      return;
    }

    try {
      const formattedPhone = '91' + phone;
      await requestOTP(formattedPhone);
      setShowOtpInput(true);
      toast.success('OTP sent successfully');
    } catch (error) {
      // Error is already handled in AuthContext
      console.error('OTP Request Error:', error);
    }
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) {
      toast.error('Please enter a valid 6-digit OTP');
      return;
    }

    try {
      await verifyOTP(otp, 'admin');
      toast.success('Login successful');
      navigate('/dashboard');
    } catch (error) {
      // Error is already handled in AuthContext
      console.error('OTP Verification Error:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md w-96">
        <h1 className="text-2xl font-bold mb-6 text-center">Fleet Admin Dashboard</h1>
        
        {!showOtpInput ? (
          <form onSubmit={handleRequestOTP} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Phone Number</label>
              <div className="mt-1 relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  className="pl-10 w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter phone number"
                  maxLength={10}
                  required
                  disabled={isLoading}
                />
              </div>
              <p className="mt-1 text-sm text-gray-500">Enter 10 digit number without country code</p>
            </div>
            <button
              type="submit"
              disabled={isLoading || !phoneRegex.test(phone)}
              className={`w-full bg-blue-600 text-white p-2 rounded-md hover:bg-blue-700 transition-colors
                ${isLoading || !phoneRegex.test(phone) ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isLoading ? 'Sending...' : 'Request OTP'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerifyOTP} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Enter OTP</label>
              <div className="mt-1 relative">
                <KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  className="pl-10 w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter 6-digit OTP"
                  maxLength={6}
                  required
                  disabled={isLoading}
                />
              </div>
              <p className="mt-1 text-sm text-gray-500">
                OTP sent to +91 {phone}
              </p>
            </div>
            <button
              type="submit"
              disabled={isLoading || otp.length !== 6}
              className={`w-full bg-blue-600 text-white p-2 rounded-md hover:bg-blue-700 transition-colors
                ${isLoading || otp.length !== 6 ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isLoading ? 'Verifying...' : 'Verify OTP'}
            </button>
            <button
              type="button"
              onClick={() => {
                setShowOtpInput(false);
                setOtp('');
              }}
              className="w-full mt-2 text-sm text-gray-600 hover:text-gray-800"
              disabled={isLoading}
            >
              Change Phone Number
            </button>
          </form>
        )}
      </div>
    </div>
  );
}