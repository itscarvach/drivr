import axios, { AxiosError } from 'axios';
import { env } from '../config/environment';
import { OTPResponse, AuthResponse } from '../types/auth';
import { Driver } from '../types/driver';

const api = axios.create({
  baseURL: env.apiBaseUrl,
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-API-Key': env.apiKey
  }
});

// Request interceptor
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    const errorMessage = error.response?.data?.message || 'An error occurred';
    console.error('API Error:', error.response?.data);
    throw new Error(errorMessage);
  }
);

export const auth = {
  requestOTP: async (phone: string): Promise<OTPResponse> => {
    const params = new URLSearchParams();
    params.append('phone', phone);
    params.append('userType', 'admin');

    const response = await api.post('/mobile/auth/v2/login', params);
    return response.data;
  },
  
  verifyOTP: async (otp: string, messageUUID: string): Promise<AuthResponse> => {
    const params = new URLSearchParams();
    params.append('otp', otp);
    params.append('messageUUID', messageUUID);
    params.append('userType', 'admin');

    const response = await api.post('/mobile/auth/v2/verify', params);
    return response.data;
  },

  refreshToken: async (refreshToken: string): Promise<AuthResponse> => {
    const params = new URLSearchParams();
    params.append('refreshToken', refreshToken);

    const response = await api.post('/mobile/auth/v2/refresh', params);
    return response.data;
  }
};

export const drivers = {
  list: async (): Promise<{ data: Driver[] }> => {
    const response = await api.get('/mobile/admin/v2/list');
    return response.data;
  },
  
  approveDocument: async (driverUUID: string, type: string, status: string, reasonForRejection?: string) => {
    const params = new URLSearchParams();
    params.append('driverUUID', driverUUID);
    params.append('type', type);
    params.append('status', status);
    if (reasonForRejection) {
      params.append('reasonForRejection', reasonForRejection);
    }

    const response = await api.post('/mobile/admin/v2/docs/approval', params);
    return response.data;
  }
};

export default api;