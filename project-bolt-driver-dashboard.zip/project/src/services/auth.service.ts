import axios, { AxiosError } from 'axios';
import { env } from '../config/environment';
import { OTPResponse, AuthResponse } from '../types/auth';

const api = axios.create({
  baseURL: env.apiBaseUrl,
  headers: {
    'Content-Type': 'multipart/form-data',
  },
});

export class AuthService {
  async requestOTP(phone: string): Promise<OTPResponse> {
    try {
      const formData = new FormData();
      formData.append('phone', phone);
      formData.append('userType', 'admin');
      
      const response = await api.post('/mobile/auth/v2/login', formData);
      return response.data;
    } catch (error) {
      if (error instanceof AxiosError) {
        throw new Error(error.response?.data?.message || 'Failed to send OTP');
      }
      throw error;
    }
  }

  async verifyOTP(data: { 
    otp: string; 
    messageUUID: string; 
    userType: string 
  }): Promise<AuthResponse> {
    try {
      const formData = new FormData();
      formData.append('otp', data.otp);
      formData.append('messageUUID', data.messageUUID);
      formData.append('userType', data.userType);
      
      const response = await api.post('/mobile/auth/v2/verify', formData);
      return response.data;
    } catch (error) {
      if (error instanceof AxiosError) {
        throw new Error(error.response?.data?.message || 'Failed to verify OTP');
      }
      throw error;
    }
  }

  async refreshToken(refreshToken: string): Promise<AuthResponse> {
    try {
      const formData = new FormData();
      formData.append('refreshToken', refreshToken);
      
      const response = await api.post('/mobile/auth/v2/refresh', formData);
      return response.data;
    } catch (error) {
      if (error instanceof AxiosError) {
        throw new Error(error.response?.data?.message || 'Failed to refresh token');
      }
      throw error;
    }
  }
}