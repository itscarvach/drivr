export interface AuthState {
  accessToken: string | null;
  userUUID: string | null;
  messageUUID: string | null;
  isAuthenticated: boolean;
}

export interface OTPResponse {
  userUUID: string;
  messageUUID: string;
  message: string;
}

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}