export interface Driver {
  uuid: string;
  name: string;
  phone: string;
  status: string;
  documents: {
    type: string;
    status: string;
  }[];
}